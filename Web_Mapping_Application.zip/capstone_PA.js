/*

Disclaimer: This web application was developed as part of an educational project.

Please recognize that the creator of this web app was a novice at web development – including HTML, CSS, and JavaScript – at the time of this work. It is recognized that there may be aspects of this code that are poorly written or even incorrect. 

*/


// Accordions (with radio checkboxes) to be used for the PA data layers and base layers
$(document).ready(
    function()
    {
        $('#accordionPA').accordion(
        {
            header: "div.hdr1",
            collapsible: true,
            active: false,	         // 'false' collapse all panels
            heightStyle: "content"   // height is only as tall as its content 
        });
        $("#accordionPA .ui-accordion-content").css({ width:"475px" });// width of the box content area
        $('input[type=radio],label').on('click',function(e){e.stopPropagation();});
    }
);

$(document).ready(
    function()
    {
        $('#baseMapAccordion').accordion(
        {
            //header: "div.hdr1",
            collapsible: true,
            active: false,	         // 'false' collapse all panels
            heightStyle: "content"   // height is only as tall as its content 
        });
        $("#baseMapAccordion .ui-accordion-content").css({ width:"130px"});// width of the box content area
        $('input[type=radio],label').on('click',function(e){e.stopPropagation();});
    }
);


// ##################################################################### // 
// !! BASE MAP/IMAGE LAYERS !! //
// ##################################################################### // 

// OpenStreeMap base map option
var osmLayer = new ol.layer.Tile({
    title: 'OpenStreetMap',
    source: new ol.source.OSM()
});

// NAIP (National Agriculture Imagery Program) imagery base layer
var ilNAIP = new ol.layer.Tile({
    title: 'NAIP-2015, Illinois',
    source: new ol.source.TileWMS({
        url: 'https://gis.apfo.usda.gov/arcgis/services/NAIP/Illinois/ImageServer/WMSServer',
        params: {
            'LAYERS': 'Illinois_2015_1m',
            'VERSION': '1.3.0'
        },
         attributions: [
            new ol.Attribution({
                html: '<a href="https://www.fsa.usda.gov/programs-and-services/aerial-photography/imagery-programs/naip-imagery">NAIP Imagery</a>.'
            })
        ]
    })
});

// Below Stamen base maps not used in current prototype but are functional
// Stamen Terrain; source: http://maps.stamen.com/
var stamenTerrain = new ol.layer.Tile({
    source: new ol.source.Stamen({
        layer: 'terrain'
    })
});

// Stamen Toner; source: http://maps.stamen.com/
var stamenToner = new ol.layer.Tile({
    source: new ol.source.Stamen({
        layer: 'toner'
    })
});

// ##################################################################################### // 

// ##################################################################################### // 
// !! OPERATIONAL DATA !! //
// ##################################################################################### // 

/*
The precision agriculture data layers (also known as the operational data layers) are currently hosted as separate WMS layers for each individual data layer – such as yield in volume (dry), bushels per acre for each 2015. This current method will generate several individual layers but will allow for a better user experience as the data will be more responsive as the tiles will be pre-generated (seeded).

Note that currently all of these operational data layers are be hosted from a local GeoServer instance (http://localhost:8080/geoserver). 
*/


// ############################################################################# 
// #### PLANTING #### //
// #############################################################################

// #############################################################################
// #### SEED SPACE (inches) #### //
// #############################################################################
// Planting - Point - 2016 - Corn - Seedspace (inches) (variable 'seed_space')
var planting_point_2016_corn_seedspace = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:planting_point_2016_corn_seedspace', 'TILED':true},
        serverType: 'geoserver'
        })
});
planting_point_2016_corn_seedspace.set('name', 'Planting - Point - 2016 - Corn - Seedspace');

// Planting - Point - 2015 - Corn - Seedspace (inches) (variable 'seed_space')
var planting_point_2015_corn_seedspace = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:planting_point_2015_corn_seedspace', 'TILED':true},
        serverType: 'geoserver'
        })
});
planting_point_2015_corn_seedspace.set('name', 'Planting - Point - 2015 - Corn - Seedspace');

// Planting - Point - 2014 - Corn - Seedspace (inches) (variable 'seed_space')
var planting_point_2014_corn_seedspace = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:planting_point_2014_corn_seedspace', 'TILED':true},
        serverType: 'geoserver'
        })
});
planting_point_2014_corn_seedspace.set('name', 'Planting - Point - 2014 - Corn - Seedspace');

// #############################################################################
// Planting - Point - 2016 - Soybean - Seedspace (inches) (variable 'seed_space')
var planting_point_2016_soybean_seedspace = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:planting_point_2016_soybean_seedspace', 'TILED':true},
        serverType: 'geoserver'
        })
});
planting_point_2016_soybean_seedspace.set('name', 'Planting - Point - 2016 - Soybean - Seedspace');

// Planting - Point - 2015 - Soybean - Seedspace (inches) (variable 'seed_space')
var planting_point_2015_soybean_seedspace = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:planting_point_2015_soybean_seedspace', 'TILED':true},
        serverType: 'geoserver'
        })
});
planting_point_2015_soybean_seedspace.set('name', 'Planting - Point - 2015 - Soybean - Seedspace');

// Planting - Point - 2014 - Soybean - Seedspace (inches) (variable 'seed_space')
var planting_point_2014_soybean_seedspace = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:planting_point_2014_soybean_seedspace', 'TILED':true},
        serverType: 'geoserver'
        })
});
planting_point_2014_soybean_seedspace.set('name', 'Planting - Point - 2014 - Soybean - Seedspace');


// #############################################################################
// #### RATE COUNT #### //
// Planting - Point - 2016 - Corn - Rate Count (ksds/ac) (variable 'rt_apd_ct_')
var planting_point_2016_corn_ratecount = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:planting_point_2016_corn_ratecount', 'TILED':true},
        serverType: 'geoserver'
        })
});
planting_point_2016_corn_ratecount.set('name', 'Planting - Point - 2016 - Corn - Rate Count');

// Planting - Point - 2015 - Corn - Rate Count (ksds/ac) (variable 'rt_apd_ct_')
var planting_point_2015_corn_ratecount = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:planting_point_2015_corn_ratecount', 'TILED':true},
        serverType: 'geoserver'
        })
});
planting_point_2015_corn_ratecount.set('name', 'Planting - Point - 2015 - Corn - Rate Count');

// Planting - Point - 2014 - Corn - Rate Count (ksds/ac) (variable 'rt_apd_ct_')
var planting_point_2014_corn_ratecount = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:planting_point_2014_corn_ratecount', 'TILED':true},
        serverType: 'geoserver'
        })
});
planting_point_2014_corn_ratecount.set('name', 'Planting - Point - 2014 - Corn - Rate Count');

// #############################################################################
// Planting - Point - 2016 - Soybean - Rate Count (ksds/ac) (variable 'rt_apd_ct_')
var planting_point_2016_soybean_ratecount = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:planting_point_2016_soybean_ratecount', 'TILED':true},
        serverType: 'geoserver'
        })
});
planting_point_2016_soybean_ratecount.set('name', 'Planting - Point - 2016 - Soybean - Rate Count');

// Planting - Point - 2015 - Soybean - Rate Count (ksds/ac) (variable 'rt_apd_ct_')
var planting_point_2015_soybean_ratecount = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:planting_point_2015_soybean_ratecount', 'TILED':true},
        serverType: 'geoserver'
        })
});
planting_point_2015_soybean_ratecount.set('name', 'Planting - Point - 2015 - Soybean - Rate Count');

// Planting - Point - 2014 - Soybean - Rate Count (ksds/ac) (variable 'rt_apd_ct_')
var planting_point_2014_soybean_ratecount = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:planting_point_2014_soybean_ratecount', 'TILED':true},
        serverType: 'geoserver'
        })
});
planting_point_2014_soybean_ratecount.set('name', 'Planting - Point - 2014 - Soybean - Rate Count');

// #############################################################################

// ############################################################################# 
// #### HARVEST #### //
// #############################################################################

// #############################################################################
// #### MOISTURE (%) #### //
// #############################################################################

// Yield - Point - 2016 - Corn - Moisture (%) (variable 'moisture__')
var yield_point_2016_corn_moisture = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2016_corn_moisture', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2016_corn_moisture.set('name', 'Yield - Point - 2016 - Corn - Moisture (%)');

// Yield - Point - 2015 - Corn - Moisture (%) (variable 'moisture__')
var yield_point_2015_corn_moisture = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2015_corn_moisture', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2015_corn_moisture.set('name', 'Yield - Point - 2015 - Corn - Moisture (%)');

// Yield - Point - 2014 - Corn - Moisture (%) (variable 'moisture__')
var yield_point_2014_corn_moisture = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2014_corn_moisture', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2014_corn_moisture.set('name', 'Yield - Point - 2014 - Corn - Moisture (%)');

// #############################################################################
// Yield - Point - 2016 - Soybean - Moisture (%) (variable 'moisture__')
var yield_point_2016_soybean_moisture = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2016_soybean_moisture', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2016_soybean_moisture.set('name', 'Yield - Point - 2016 - Soybean - Moisture (%)');

// Yield - Point - 2015 - Soybean - Moisture (%) (variable 'moisture__')
var yield_point_2015_soybean_moisture = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2015_soybean_moisture', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2015_soybean_moisture.set('name', 'Yield - Point - 2015 - Soybean - Moisture (%)');

// Yield - Point - 2014 - Soybean - Moisture (%) (variable 'moisture__')
var yield_point_2014_soybean_moisture = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2014_soybean_moisture', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2014_soybean_moisture.set('name', 'Yield - Point - 2014 - Soybean - Moisture (%)');

// #############################################################################
// #### VOLUME (dry) (bu/ac) #### //
// #############################################################################
// Yield - Point - 2016 - Corn - Yield, Volume (dry) (bu/ac) (variable 'yld_vol_dr')
var yield_point_2016_corn_yieldvolume = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2016_corn_yieldvolume', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2016_corn_yieldvolume.set('name', 'Yield - Point - 2016 - Corn - Volume (dry) (bu/ac)');

// Yield - Point - 2015 - Corn - Yield, Volume (dry) (bu/ac) (variable 'yld_vol_dr')
var yield_point_2015_corn_yieldvolume = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2015_corn_yieldvolume', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2015_corn_yieldvolume.set('name', 'Yield - Point - 2015 - Corn - Volume (dry) (bu/ac)');

// Yield - Point - 2014 - Corn - Yield, Volume (dry) (bu/ac) (variable 'yld_vol_dr')
var yield_point_2014_corn_yieldvolume = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2014_corn_yieldvolume', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2014_corn_yieldvolume.set('name', 'Yield - Point - 2014 - Corn - Volume (dry) (bu/ac)');

// #############################################################################
// Yield - Point - 2016 - Soybean - Yield, Volume (dry) (bu/ac) (variable 'yld_vol_dr')
var yield_point_2016_soybean_yieldvolume = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2016_soybean_yieldvolume', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2016_soybean_yieldvolume.set('name', 'Yield - Point - 2016 - Soybean - Volume (dry) (bu/ac)');

// Yield - Point - 2015 - Soybean - Yield, Volume (dry) (bu/ac) (variable 'yld_vol_dr')
var yield_point_2015_soybean_yieldvolume = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2015_soybean_yieldvolume', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2015_soybean_yieldvolume.set('name', 'Yield - Point - 2015 - Soybean - Volume (dry) (bu/ac)');

// Yield - Point - 2014 - Soybean - Yield, Volume (dry) (bu/ac) (variable 'yld_vol_dr')
var yield_point_2014_soybean_yieldvolume = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2014_soybean_yieldvolume', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2014_soybean_yieldvolume.set('name', 'Yield - Point - 2014 - Soybean - Volume (dry) (bu/ac)');

// #############################################################################
// #### Mass (dry) (lb/ac) #### //
// #############################################################################
// Yield - Point - 2016 - Corn - Yield, Mass (dry) (lb/ac) (variable 'yld_mass_dr')
var yield_point_2016_corn_yieldmass = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2016_corn_yieldmass', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2016_corn_yieldmass.set('name', 'Yield - Point - 2016 - Corn - Mass (dry) (lb/ac)');

// Yield - Point - 2015 - Corn - Yield, Mass (dry) (lb/ac) (variable 'yld_mass_dr')
var yield_point_2015_corn_yieldmass = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2015_corn_yieldmass', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2015_corn_yieldmass.set('name', 'Yield - Point - 2015 - Corn - Mass (dry) (lb/ac)');

// Yield - Point - 2014 - Corn - Yield, Mass (dry) (lb/ac) (variable 'yld_mass_dr')
var yield_point_2014_corn_yieldmass = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2014_corn_yieldmass', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2014_corn_yieldmass.set('name', 'Yield - Point - 2014 - Corn - Mass (dry) (lb/ac)');


// #############################################################################
// Yield - Point - 2016 - Soybean - Yield, Mass (dry) (lb/ac) (variable 'yld_mass_dr')
var yield_point_2016_soybean_yieldmass = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2016_soybean_yieldmass', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2016_soybean_yieldmass.set('name', 'Yield - Point - 2016 - Soybean - Mass (dry) (lb/ac)');

// Yield - Point - 2015 - Soybean - Yield, Mass (dry) (lb/ac) (variable 'yld_mass_dr')
var yield_point_2015_soybean_yieldmass = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2015_soybean_yieldmass', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2015_soybean_yieldmass.set('name', 'Yield - Point - 2015 - Soybean - Mass (dry) (lb/ac)');

// Yield - Point - 2014 - Soybean - Yield, Mass (dry) (lb/ac) (variable 'yld_mass_dr')
var yield_point_2014_soybean_yieldmass = new ol.layer.Tile({
    opacity: 1.0,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:yield_point_2014_soybean_yieldmass', 'TILED':true},
        serverType: 'geoserver'
        })
});
yield_point_2014_soybean_yieldmass.set('name', 'Yield - Point - 2014 - Soybean - Mass (dry) (lb/ac)');

// ##################################################################### // 

// ##################################################################### // 
// !! BASE REFERENCE DATA LAYERS !! //
// ##################################################################### // 

// Hydrology Layers, symbolized by 'major' and 'minor' (currently not tiled)
var hydrologyLoganDewittWMS = new ol.layer.Image({
    title: 'Hydrology - Logan and Dewitt Counties',
    opacity: 0.8,
    source: new ol.source.ImageWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:nhd24kst_l_il_logan_dewitt_3857'
        }
    })
});
hydrologyLoganDewittWMS.set('name', 'Hydrology - Logan and Dewitt Counties');

// Roads layer - subset of Logan and Dewitt counties (currently not tiled)
var roadsLoganDewittSubsetWMS = new ol.layer.Image({
    title: 'Roads - Logan and Dewitt Counties, subsets',
    opacity: 0.9,
    source: new ol.source.ImageWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:street100k_l_il_studyarea_WPSG3857'
        }
    })
});
roadsLoganDewittSubsetWMS.set('name', 'Testing - Road data');

// Field polygons (currently tiled)
var fieldPolygonsWMSTile = new ol.layer.Tile({
    opacity: .60,
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/wms',
        params: {
            'LAYERS': 'PrecisionAg_v1:field_polygons_v1', 'TILED':true},
        serverType: 'geoserver'
        })
});
fieldPolygonsWMSTile.set('name', 'Field Polygons');

// ##################################################################### // 

// ##################################################################### // 
// !! GENERATING WEB MAP !! //
// ##################################################################### // 

var baseGroup = new ol.layer.Group({
    title: 'Base Layers',
    layers: []
});

// Note that any base layers that wanted to be displayed by default, need to be added in 'layers' below (regardless of if HTML checkbox is checked)
var layers = [ilNAIP, fieldPolygonsWMSTile, roadsLoganDewittSubsetWMS, hydrologyLoganDewittWMS]

var view = new ol.View({
    center: ol.proj.transform([-89.193242, 40.143251], 'EPSG:4326', 'EPSG:3857'),
    zoom: 12
});

// OL: Zoom control
var zoomControl = new ol.control.Zoom({
  zoomInTipLabel: 'Zoom closer in',         // Customized tool tips
  zoomOutTipLabel: 'Zoom further out',      // Customized tool tips
  className: 'ol-zoom custom-zoom-control'  // Modified to include both default class name for zoom control (ol-zoom) in order to inherit default OL styling and a custom class of 'custom-zoom-control.' Can use this custome class name as CSS hook to overrids
});

var attributionControl = new ol.control.Attribution({
  collapsible: false,
  collapsed: false
});

/*var rotateControl = new ol.control.Rotate({
  autoHide: false
});*/

var map = new ol.Map({
    layers: baseGroup, layers,
    target: 'map',
    controls: [],
    view: view
});

map.addControl(zoomControl);
map.addControl(attributionControl);
//map.addControl(rotateControl);


// *****************************************************************************

// ##################################################################### // 
// !! PRECISION AGRICULTURE DATA RADIO BUTTONS !! //
// ##################################################################### // 

// Radio buttons to turn data layers on and off
//Turn layers on and off based on ID of button clicked
    // ID is what was assigned as 'id' in the HTML for each checkbox

// ######## 2016 ######## //
// #### 2016: Soybean #### //
$(".check").change(function(index) {
    var targetid = $(this).attr("id");
        switch(targetid) {
        case "plantingPoint2016SoybeanSeedSpace":
            {if(plantingPoint2016SoybeanSeedSpace.checked) {
                map.addLayer(planting_point_2016_soybean_seedspace);
            } else {
                map.removeLayer(planting_point_2016_soybean_seedspace);
            }};
        break
        case "plantingPoint2016SoybeanRateCount":
            {if(plantingPoint2016SoybeanRateCount.checked) {
                map.addLayer(planting_point_2016_soybean_ratecount);
            } else {
                map.removeLayer(planting_point_2016_soybean_ratecount);
            }};
        break
        case "yieldPoint2016SoybeanMoisture":
            {if(yieldPoint2016SoybeanMoisture.checked) {
                map.addLayer(yield_point_2016_soybean_moisture);
            } else {
                map.removeLayer(yield_point_2016_soybean_moisture);
            }};        
        break
        case "yieldPoint2016SoybeanYieldVolume":
            {if(yieldPoint2016SoybeanYieldVolume.checked) {
                map.addLayer(yield_point_2016_soybean_yieldvolume);
            } else {
                map.removeLayer(yield_point_2016_soybean_yieldvolume);
            }};
        break
        case "yieldPoint2016SoybeanYieldMass":
            {if(yieldPoint2016SoybeanYieldMass.checked) {
                map.addLayer(yield_point_2016_soybean_yieldmass);
            } else {
                map.removeLayer(yield_point_2016_soybean_yieldmass);
            }};                
        }
});

// #### 2016: Corn #### //
$(".check").change(function(index) {
    var targetid = $(this).attr("id");
        switch(targetid) {
        case "plantingPoint2016CornSeedSpace":
            {if(plantingPoint2016CornSeedSpace.checked) {
                map.addLayer(planting_point_2016_corn_seedspace);
            } else {
                map.removeLayer(planting_point_2016_corn_seedspace);
            }};
        break
        case "plantingPoint2016CornRateCount":
            {if(plantingPoint2016CornRateCount.checked) {
                map.addLayer(planting_point_2016_corn_ratecount);
            } else {
                map.removeLayer(planting_point_2016_corn_ratecount);
            }};
        break
        case "yieldPoint2016CornMoisture":
            {if(yieldPoint2016CornMoisture.checked) {
                map.addLayer(yield_point_2016_corn_moisture);
            } else {
                map.removeLayer(yield_point_2016_corn_moisture);
            }}; 
        break
        case "yieldPoint2016CornYieldVolume":
            {if(yieldPoint2016CornYieldVolume.checked) {
                map.addLayer(yield_point_2016_corn_yieldvolume);
            } else {
                map.removeLayer(yield_point_2016_corn_yieldvolume);
            }};
        break
        case "yieldPoint2016CornYieldMass":
            {if(yieldPoint2016CornYieldMass.checked) {
                map.addLayer(yield_point_2016_corn_yieldmass);
            } else {
                map.removeLayer(yield_point_2016_corn_yieldmass);
            }};  
        }
});

// ######## 2015 ######## //
// #### 2015: Soybean #### //
$(".check").change(function(index) {
    var targetid = $(this).attr("id");
        switch(targetid) {
        case "plantingPoint2015SoybeanSeedSpace":
            {if(plantingPoint2015SoybeanSeedSpace.checked) {
                map.addLayer(planting_point_2015_soybean_seedspace);
            } else {
                map.removeLayer(planting_point_2015_soybean_seedspace);
            }};
        break
        case "plantingPoint2015SoybeanRateCount":
            {if(plantingPoint2015SoybeanRateCount.checked) {
                map.addLayer(planting_point_2015_soybean_ratecount);
            } else {
                map.removeLayer(planting_point_2015_soybean_ratecount);
            }};
        break
        case "yieldPoint2015SoybeanMoisture":
            {if(yieldPoint2015SoybeanMoisture.checked) {
                map.addLayer(yield_point_2015_soybean_moisture);
            } else {
                map.removeLayer(yield_point_2015_soybean_moisture);
            }};        
        break
        case "yieldPoint2015SoybeanYieldVolume":
            {if(yieldPoint2015SoybeanYieldVolume.checked) {
                map.addLayer(yield_point_2015_soybean_yieldvolume);
            } else {
                map.removeLayer(yield_point_2015_soybean_yieldvolume);
            }};
        break
        case "yieldPoint2015SoybeanYieldMass":
            {if(yieldPoint2015SoybeanYieldMass.checked) {
                map.addLayer(yield_point_2015_soybean_yieldmass);
            } else {
                map.removeLayer(yield_point_2015_soybean_yieldmass);
            }};                
        }
});

// #### 2015: Corn #### //
$(".check").change(function(index) {
    var targetid = $(this).attr("id");
        switch(targetid) {
        case "plantingPoint2015CornSeedSpace":
            {if(plantingPoint2015CornSeedSpace.checked) {
                map.addLayer(planting_point_2015_corn_seedspace);
            } else {
                map.removeLayer(planting_point_2015_corn_seedspace);
            }};
        break
        case "plantingPoint2015CornRateCount":
            {if(plantingPoint2015CornRateCount.checked) {
                map.addLayer(planting_point_2015_corn_ratecount);
            } else {
                map.removeLayer(planting_point_2015_corn_ratecount);
            }};
        break
        case "yieldPoint2015CornMoisture":
            {if(yieldPoint2015CornMoisture.checked) {
                map.addLayer(yield_point_2015_corn_moisture);
            } else {
                map.removeLayer(yield_point_2015_corn_moisture);
            }}; 
        break
        case "yieldPoint2015CornYieldVolume":
            {if(yieldPoint2015CornYieldVolume.checked) {
                map.addLayer(yield_point_2015_corn_yieldvolume);
            } else {
                map.removeLayer(yield_point_2015_corn_yieldvolume);
            }};
        break
        case "yieldPoint2015CornYieldMass":
            {if(yieldPoint2015CornYieldMass.checked) {
                map.addLayer(yield_point_2015_corn_yieldmass);
            } else {
                map.removeLayer(yield_point_2015_corn_yieldmass);
            }};  
        }
});

// ######## 2014 ######## //
// #### 2014: Soybean #### //
$(".check").change(function(index) {
    var targetid = $(this).attr("id");
        switch(targetid) {
        case "plantingPoint2014SoybeanSeedSpace":
            {if(plantingPoint2014SoybeanSeedSpace.checked) {
                map.addLayer(planting_point_2014_soybean_seedspace);
            } else {
                map.removeLayer(planting_point_2014_soybean_seedspace);
            }};
        break
        case "plantingPoint2014SoybeanRateCount":
            {if(plantingPoint2014SoybeanRateCount.checked) {
                map.addLayer(planting_point_2014_soybean_ratecount);
            } else {
                map.removeLayer(planting_point_2014_soybean_ratecount);
            }};
        break
        case "yieldPoint2014SoybeanMoisture":
            {if(yieldPoint2014SoybeanMoisture.checked) {
                map.addLayer(yield_point_2014_soybean_moisture);
            } else {
                map.removeLayer(yield_point_2014_soybean_moisture);
            }};        
        break
        case "yieldPoint2014SoybeanYieldVolume":
            {if(yieldPoint2014SoybeanYieldVolume.checked) {
                map.addLayer(yield_point_2014_soybean_yieldvolume);
            } else {
                map.removeLayer(yield_point_2014_soybean_yieldvolume);
            }};
        break
        case "yieldPoint2014SoybeanYieldMass":
            {if(yieldPoint2014SoybeanYieldMass.checked) {
                map.addLayer(yield_point_2014_soybean_yieldmass);
            } else {
                map.removeLayer(yield_point_2014_soybean_yieldmass);
            }};                
        }
});

// #### 2014: Corn #### //
$(".check").change(function(index) {
    var targetid = $(this).attr("id");
        switch(targetid) {
        case "plantingPoint2014CornSeedSpace":
            {if(plantingPoint2014CornSeedSpace.checked) {
                map.addLayer(planting_point_2014_corn_seedspace);
            } else {
                map.removeLayer(planting_point_2014_corn_seedspace);
            }};
        break
        case "plantingPoint2014CornRateCount":
            {if(plantingPoint2014CornRateCount.checked) {
                map.addLayer(planting_point_2014_corn_ratecount);
            } else {
                map.removeLayer(planting_point_2014_corn_ratecount);
            }};
        break
        case "yieldPoint2014CornMoisture":
            {if(yieldPoint2014CornMoisture.checked) {
                map.addLayer(yield_point_2014_corn_moisture);
            } else {
                map.removeLayer(yield_point_2014_corn_moisture);
            }}; 
        break
        case "yieldPoint2014CornYieldVolume":
            {if(yieldPoint2014CornYieldVolume.checked) {
                map.addLayer(yield_point_2014_corn_yieldvolume);
            } else {
                map.removeLayer(yield_point_2014_corn_yieldvolume);
            }};
        break
        case "yieldPoint2014CornYieldMass":
            {if(yieldPoint2014CornYieldMass.checked) {
                map.addLayer(yield_point_2014_corn_yieldmass);
            } else {
                map.removeLayer(yield_point_2014_corn_yieldmass);
            }};  
        }
});

// Farm Field Polygons
$(".check").change(function(index) {
    var targetid = $(this).attr("id");
        switch(targetid) {
        case "fieldpolygons_v1":
            {if(fieldpolygons_v1.checked) {
                layers.insertAt(1, fieldPolygonsWMSTile);
            } else {
                map.removeLayer(fieldPolygonsWMSTile);
            }};
        break
        }
});

// ##################################################################### // 
// !! BASE DATA RADIO BUTTONS !! //
// ##################################################################### // 

// Radio buttons established to turn on/off the base map and imagery layers. 
// Needed to ensure that only one was being displayed (and radio button checked) at a time.

// Resources to help with setting base layer:
//https://stackoverflow.com/questions/26686191/updating-basemaps-in-openlayers-3
    // Also would work:  map.getLayers().setAt(1, basemap2);
var layers = this.map.getLayers();

$(".baseLayerRadios").change(function(index) {
    var targetid = $(this).attr("id");
    //Turn layers on and off based on ID of button clicked
    switch(targetid) {
        case "naip":
            {if ((naip.checked)) {
                map.removeLayer(osmLayer);
                layers.insertAt(0, ilNAIP);
                osmLayer.checked=false;
            } // 'else/if' does not seem to change any results
            else if ((naip.checked) && (osmLayer.checked)) {
                map.removeLayer(osmLayer);
                osmLayer.checked=false;
                layers.insertAt(0, ilNAIP);
            } else {
                naip.checked = false;
                map.removeLayer(ilNAIP);
                osmLayer.checked=true;
                layers.insertAt(0, osmLayer);
            }};
        break
        case "osm":
            {if ((osm.checked)) {
                map.removeLayer(ilNAIP);
                naip.checked = false;
                layers.insertAt(0, osmLayer);
            } else {
                osmLayer.checked = false;
                map.removeLayer(osmLayer);
                naip.checked = true;
                layers.insertAt(0, ilNAIP);
            }};
        break
    }
});

$(".baseLayerRadios").change(function(index) {
    var targetid = $(this).attr("id");
    //Turn layers on and off based on ID of button clicked
    switch(targetid) {
        case "hydro":
            {if ((hydro.checked)) {
                layers.insertAt(2, hydrologyLoganDewittWMS);
            } else {
                hydro.checked = false;
                map.removeLayer(hydrologyLoganDewittWMS);
            }};
        break
        case "roads":
            {if ((roads.checked)) {
                layers.insertAt(3, roadsLoganDewittSubsetWMS);
            } else {
                roads.checked = false;
                map.removeLayer(roadsLoganDewittSubsetWMS);
            }};
        break
    }
});


// #############################################################################
// #### PLOTTING #### //
// #############################################################################
var tm = TweenMax;

// Make chart draggable and resizeable
$(document).ready(function () {
    $("#chart2").resizable().draggable()
});

// Click to close chart
$('#closeChart2').click(function() {
    tm.to('#chart2', .4, {
        transform: 'scale(0)',
        opacity: '0',
        ease: Power1.easeIn
    });
    tm.to('#chart2', 0.4, {
        display: 'block',
        ease: Power1.easeIn,
        delay: 0.4
    });
    tm.to('#chartIcon', 0.4, {
        display: 'block', 
        opacity: '1',
        ease: Power1.easeIn,
        delay: 0.2
    });
});

// Click to open chart
$('#chartIcon').click(function() {
    tm.to('#chart2', .4, {
        display: 'block',
        transform: 'scale(1)',
        opacity: '1',       
        ease: Power1.easeIn
    });
    tm.to('#chartIcon', 0.4, {
        display: 'block',
        opacity: '1',       // Changing opactiy from 0 to 1 prevented the chart icon from disappearing (probably could just delete the second statement, but kept for now)
        ease: Power1.easeIn,
        delay: 0.2
    });
});

// #############################################################################
// #### PLOTLY SAMPLE #### //
// #############################################################################
// Plotly sample - working 
// Source for fluid layout to be able to re-size window: https://plot.ly/javascript/responsive-fluid-layout/

/*
var d3 = Plotly.d3;
var plotlyWidth = 100,
    plotlyHeight = 100
var gd3 = d3.select('#barChart')
    .append('div')
.attr("z-index", '8500')
.style({
    width: plotlyWidth + '%',
    'margin-left': (100 - plotlyWidth) / 2 + '%',
    
    height: plotlyHeight + '%',
    'margin-top': (100 - plotlyHeight) / 2 + 'vh'
});

var gd = gd3.node();

d3.csv('https://raw.githubusercontent.com/plotly/datasets/master/gapminderDataFiveYear.csv', function(err, rows){
var YEAR = 2007;
var continents = ['Asia', 'Europe', 'Africa', 'Oceania', 'Americas'];
var POP_TO_PX_SIZE = 2e5;
function unpack(rows, key) {
  return rows.map(function(row) { return row[key]; });
}

var data = continents.map(function(continent) {
  var rowsFiltered = rows.filter(function(row) {
      return (row.continent === continent) && (+row.year === YEAR);
  });
  return {
      mode: 'markers',
      name: continent,
      x: unpack(rowsFiltered, 'lifeExp'),
      y: unpack(rowsFiltered, 'gdpPercap'),
      text: unpack(rowsFiltered, 'country'),
      marker: {
          sizemode: 'area',
          size: unpack(rowsFiltered, 'pop'),
          sizeref: POP_TO_PX_SIZE
      }
  };
});
var layout = {
  autosize: true,
  xaxis: {title: 'Life Expectancy'},
  yaxis: {title: 'GDP per Capita', type: 'log'},
  margin: {t: 20},
  hovermode: 'closest'
};
Plotly.newPlot(gd, data, layout, {
    showLink: false,
    displayModeBar: 'hover',       // false removes Plotly menu at the top; true keeps menu in place all the time; 'hover' only displays menu when cursor within plot
    showTips: true
    });        
//Plotly.plot('barChart', data, layout, {showLink: false});
});
// Notes for Plotly config file: https://github.com/plotly/plotly.js/blob/master/src/plot_api/plot_config.js#L22-L86

window.onresize = function () {
    Plotly.Plots.resize(gd);
};
*/
// Note that 'barChart' is the HTML div used to "host" the Plotly chart


// #############################################################################
// PROJECT DATA
// CORN DATA
var d3 = Plotly.d3;
var plotlyWidth = 100,
    plotlyHeight = 100
var gd3 = d3.select('#barChart')
    .append('div')
.attr("z-index", '8500')
.style({
    width: plotlyWidth + '%',
    'margin-left': (100 - plotlyWidth) / 2 + '%',
    
    height: plotlyHeight + '%',
    'margin-top': (100 - plotlyHeight) / 2 + 'vh'
});

var gd = gd3.node();

var years = ['2014', '2015', '2016']

d3.csv('Data_SummaryChart_Yield_Dry_CORN.csv', (err, rows) => {
  var data = years.map(y => {
        var d = rows.filter(r => r.year === y)

        return {
          type: 'bar',
          name: y,
          x: d.map(r => r.field_name),            
          y: d.map(r => r.avg_yield_dry_corn),          
        }
      })    

    var layout = {
        autosize: true, 
        margin: {t: 60, b: 150},                   // Default 80; https://plot.ly/javascript/reference/#layout-margin 
        //height: 594,                             // This was causing issues with how chart was sizing w/existing #chart2
        //width: 1000, 
        title: 'Average Yield: by Field, by Year', 
      
        xaxis: {
            categoryorder: "category ascending",    // Orders x-axis data by 'field_name' alphabetically
            //categoryorder:"array",
            //categoryarray:[r.field_name],
            autorange: true, 
            range: [0.5, 6.0], 
            title: 'Individual Farms', 
            type: 'category'
        }, 
        yaxis: {
            autorange: true, 
            range: [0, 0.336842105263], 
            title: 'Average Yield Per Acre', 
            type: 'linear'
      }
    };
      
    Plotly.newPlot(gd, data, layout, {
                        showLink: false,
                        displayModeBar: 'hover',       // false removes Plotly menu at the top; true keeps menu in place all the time; 'hover' only displays menu when cursor within plot
                        showTips: true
    }); 

});
    // Notes for Plotly config file (for Plotly bar w/in chart): https://github.com/plotly/plotly.js/blob/master/src/plot_api/plot_config.js#L22-L86    

window.onresize = function () {
    Plotly.Plots.resize(gd);
};
// Note that 'barChart' is the HTML div used to "host" the Plotly chart

// ***************************************************************************** 