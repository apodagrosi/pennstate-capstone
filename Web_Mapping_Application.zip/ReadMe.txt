SUMMARY:
This web application, developed as a prototype, performs basic functionality to map data related to precision agriculture operations. The application is intended to be easy to use with three basic buttons/drop-downs providing data layers to be mapped and a chart window to open. Functionality of the web app include:
-- Utilizing OpenLayers3 to display a background map (NAIP imagery and OSM) and WMS layers, currently from a locally-hosted GeoServer instance.
	-- The WMS layers consist of precision agriculture data (data collected during planting and harvesting information) and base reference layers such as hydrology and transportation layers.
-- Basic functionality to create a summary chart (average yield by field, by year), utilizing Plotly�s JavaScript library, is included by selecting the chart icon.
-- Web development applications utilized include: OpenLayers3, jQuery UI, and Plotly (JavaScript library)

Disclaimer: This web application was developed as part of an educational project.

Please recognize that the creator of this web app was a novice at web development � including HTML, CSS, and JavaScript � at the time of this work. It is recognized that there may be aspects of this code that are poorly written or even incorrect. 
